import { SafeAreaView } from 'react-native-safe-area-context';
import { View } from 'react-native';
import { FlatList } from 'react-native';
import { StyleSheet } from 'react-native';
import { Text } from 'react-native';
import { Image } from 'react-native';
import React, { useEffect, useState } from 'react';
import { TouchableOpacity } from 'react-native';

const ListaView = ({ navigation }) => {

    const [DATA, setDATA] = useState([]);


    const loadDataThroughJason = async () => {
        try {
            const response = await fetch('https://raw.githubusercontent.com/Budy-Dev/teste/main/fastfood.json')
            const json = await response.json();
            setDATA(json);
        } catch (error) {
            console.log("Occorreu um erro")
        }
    }



    useEffect(() => {
        loadDataThroughJason();
    }, []);

    return (
        <SafeAreaView style={styles.list}>
            <FlatList keyExtractor={item => item.nome} data={DATA}
                renderItem={({ item }) => (
                    <TouchableOpacity style={styles.itensDaLista}
                        onPress={() => navigation.navigate("DetalhesView", {
                            restauranteNome: item.nome,
                            restauranteLocation: item.localizacao,
                            restauranteDistancia: item.distancia,
                            restauranteCardapio: item.cardapio,
                            restauranteImg: item.img
                        })}>

                        <View style={{ flex: 1, flexDirection: 'row' }}>
                            <Image style={styles.img} source={require('./assets/img/' + item.logo)} />

                            <View style={{ flex: 1, flexDirection: 'column' }}>
                                <Text style={{ fontWeight: '400', fontSize: 24, paddingLeft: 20 }}>{item.nome} - {item.localizacao}</Text>
                                <Text style={{ paddingLeft: 20 }}>Distância: {item.distancia}</Text>
                                <Text style={{ paddingLeft: 20 }}>Localização: {item.localizacao}</Text>
                            </View>
                        </View>



                    </TouchableOpacity>
                )}
            />
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    list: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',

    },
    img: {
        width: 80,
        heigh: 400
    },
    itensDaLista: {
        padding: 24,
        marginVertical: 8,
        marginHorizontal: 20,
        borderColor: 'gray',
        borderBottomWidth: 1

    },
    title: {
        //: 'lucida grande', tahoma, verdana, arial, sans-serif;
        fontFamily: 'lucida grande',
        fontSize: 32,
    },

});

export default ListaView;