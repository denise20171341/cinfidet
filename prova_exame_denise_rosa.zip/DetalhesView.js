import { Text } from "react-native"
import { View } from "react-native";
import { Image } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { FlatList } from "react-native";
import { TouchableOpacity } from "react-native";
import { StyleSheet } from "react-native";

const DetalhesView = ({ route, navigation }) => {

    const { restauranteNome, restauranteLocation, restauranteDistancia, restauranteCardapio, restauranteImg } = route.params;

    return (

        <SafeAreaView style={{ flex: 1 }}>
            <Image style={styles.img} source={require('./assets/img/' + restauranteImg)} />
            <FlatList data={restauranteCardapio}
                renderItem={({ item }) => (
                    <TouchableOpacity style={styles.meusItens} onPress={() => {
                        navigation.navigate('FormView', {
                            nome: restauranteNome,
                            opcao: item.opcao,
                            preco: item.preco
                        })
                    }}
                    >
                        <View style={{ flex: 1, flexDirection: 'row' }}>
                            <Image style={styles.imgCardapio} source={require('./assets/img/' + item.img)} />
                            <View style={{ flex: 1, flexDirection: 'column' }}>
                                <Text>Opção: {item.opcao}</Text>
                                <Text>Preco: {item.preco}</Text>
                            </View>
                        </View>
                    </TouchableOpacity>
                )}
                keyExtractor={item => { item.opcao }}
            />
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({

    meusItens: {
        padding: 24,

    },
    imgCardapio: {
        width: 100,
        height: 100
    },
    img: {
        height: 320,
        width: 600,
    }
});

export default DetalhesView