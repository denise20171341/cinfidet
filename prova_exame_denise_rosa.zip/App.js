import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import DetalhesView from './DetalhesView';
import ListaView from './ListaView';
import FormView from './FormView';
var Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>

      <Stack.Navigator>

        <Stack.Screen
          name="ListaView"
          component={ListaView} />
        <Stack.Screen
          name="DetalhesView"
          component={DetalhesView} />
        <Stack.Screen
          name="FormView"
          component={FormView} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
