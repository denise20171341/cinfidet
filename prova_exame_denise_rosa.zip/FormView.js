import { TextInput, View, Text } from "react-native";
import { StyleSheet } from "react-native";
import { Button } from "react-native";
import * as SQLite from "expo-sqlite";
import { useEffect, useState } from "react";

const db = SQLite.openDatabase("restaurantes");




function FormView({ route, navigation }) {

    useEffect(() => {
        db.transaction(
            (transaction) => {
                transaction.executeSql(
                    `CREATE TABLE IF NOT EXISTS restaurante (
                    id integer primary key autoincrement,
                    nome text,
                    cartao text
                  );`
                );
            },
            (error) => {
                console.log(error);
            },
            () => {
                console.log("Tabela criada");
            }
        );
    }, [])

    const [name, updateNome] = useState('');
    const [cartao, updateCartao] = useState('');

    const { nome, opcao, preco } = route.params;
    return (
        <View style={{ margin: 'auto', padding: 50 }} >
            <Text style={{ fontWeight: 'bold' }}>Pedido</Text>

            <View style={styles.cima}>
                <Text style={{ padding: 1, margin: 'auto', fontWeight: '500', fontSize: 16 }}>{nome}!</Text>
                <Text style={{ marginTop: 15, margin: 'auto', fontWeight: '500', fontSize: 16 }}>{opcao}: {preco}</Text>
            </View>

            <View style={styles.inputs}>
                <TextInput style={styles.input} placeholder="Nome" onChangeText={(text) => updateNome(text)}></TextInput>
                <TextInput style={styles.input} placeholder="Cartão de pagamento" onChangeText={(text) => updateCartao(text)}></TextInput>

                <Button title="Realizar pedido" onPress={() => inserir(name, cartao)}></Button>
            </View>

        </View>
    )

}

db.transaction((tx) => {

})

export default FormView;

const styles = StyleSheet.create({
    cima: {
        width: 400,
        backgroundColor: "#6596eb",
        flex: 1,
        flexDirection: 'column',
        padding: 30
    },
    inputs: {
        paddingTop: 30,
        marginBottom: 400,


    },
    input: {
        backgroundColor: 'white',
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderColor: 'grey',
        borderWidth: 1,
        marginVertical: 7
    }
})


function inserir(name, cartao) {

    db.transaction(
        (transaction) => {
            transaction.executeSql(`INSERT INTO restaurantes (name, cartao) VALUES ('${name}', '${cartao}');`);
        },
        console.error,
        () => {
            console.log("Restaurantes inserida");
        }
    );
}